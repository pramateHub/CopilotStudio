# Azure AI Studio Exercises

This repo contains instructions and assets to support practical exercises in [Microsoft Learn modules on Azure AI Studio](https://docs.microsoft.com/training).

## Reporting issues

If you encounter any problems in the exercises, please report them as **issues** in this repo.
